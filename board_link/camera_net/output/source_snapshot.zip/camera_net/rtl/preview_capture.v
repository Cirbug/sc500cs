// One immutable RGB332 thumbnail, transferred by a request/ack toggle.
// The network owns the RAM after publication until release returns. No DDR port.
module preview_capture #(parameter W=1920, H=1080, STEP=12)(
 input pclk, nclk, rst_n, vs, de, input [23:0] rgb,
 input release_frame, input [13:0] rd_addr, output reg [7:0] rd_data,
 output ready
);
 localparam SIZE=(W/STEP)*(H/STEP);
 reg [7:0] mem[0:SIZE-1];
 reg published, released;
 (* ASYNC_REG="TRUE" *) reg rel1,rel2,pub1,pub2;
 reg vs_d,de_d,active;
 reg [11:0] x,y;
 reg [3:0] xm,ym;
 reg [13:0] count;
 reg malformed;
 assign ready=pub2!=released;
 always @(posedge nclk or negedge rst_n)
   if(!rst_n) begin pub1<=0;pub2<=0;released<=0;end
   else begin pub1<=published;pub2<=pub1;if(release_frame) released<=pub2;end
 always @(posedge nclk) rd_data<=mem[rd_addr];
 always @(posedge pclk or negedge rst_n) begin
   if(!rst_n) begin
     rel1<=0;rel2<=0;published<=0;vs_d<=0;de_d<=0;
     active<=0;x<=0;y<=0;xm<=0;ym<=0;count<=0;malformed<=0;
   end else begin
     rel1<=released;rel2<=rel1;vs_d<=vs;de_d<=de;
     if(vs && !vs_d) begin
       x<=0;y<=0;xm<=0;ym<=0;count<=0;malformed<=0;
       if(active) begin
         active<=0;
         if(count==SIZE && !malformed && y==H) published<=~published;
       end else active<=(published==rel2);
     end else if(active) begin
       if(de) begin
         if(x>=W || y>=H) malformed<=1;
         if(xm==0 && ym==0 && x<W && y<H && count<SIZE) begin
           mem[count]<={rgb[23:21],rgb[15:13],rgb[7:6]};count<=count+1'b1;
         end
         if(x<4095) x<=x+1'b1;
         xm<=(xm==STEP-1)?0:xm+1'b1;
       end
       if(de_d && !de) begin
         if(x!=W) malformed<=1;
         x<=0;xm<=0;if(y<4095)y<=y+1'b1;
         ym<=(ym==STEP-1)?0:ym+1'b1;
       end
     end
   end
 end
endmodule
