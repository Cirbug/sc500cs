
`timescale 1ps/1ps 

module MCU_521bd43d073e
#(
	parameter  MCU_JTAG_SEL      = "1",
	parameter  MCU_RESET_VECTOR  = 32'hFFFFFFFF,
	parameter  AHB_FREQ          = "50",
	parameter  QSPI_FREQ         = "20",
    parameter  MCU_DPLL_BYPASS   = "DISABLE",
	parameter  MCU_DPLL_POST_DIV =   0 
)
(
    output        core_sysrst,

	input         jtag_tck,
	input         jtag_tms,
	input         jtag_tdi,
	output        jtag_tdo,

	input         gpio0_in,
	output        gpio0_out,
	output        gpio0_dir,

	input         gpio1_in,
	output        gpio1_out,
	output        gpio1_dir,

	input         gpio2_in,
	output        gpio2_out,
	output        gpio2_dir,

	input         gpio3_in,
	output        gpio3_out,
	output        gpio3_dir,

	input         gpio4_in,
	output        gpio4_out,
	output        gpio4_dir,

	input         gpio5_in,
	output        gpio5_out,
	output        gpio5_dir,

	input         gpio6_in,
	output        gpio6_out,
	output        gpio6_dir,

	input         gpio7_in,
	output        gpio7_out,
	output        gpio7_dir,

	output        uart0_tx,
	input         uart0_rx,

	output        uart1_tx,
	input         uart1_rx,

	input         i2c_sda_in,
	output        i2c_sda_out,
	output        i2c_sda_sel,
	input         i2c_scl_in,
	output        i2c_scl_out,
	output        i2c_scl_sel,

	output        qspi1_clk,
	output        qspi1_ss,
	input         qspi1_d0_in,
	input         qspi1_d1_in,
	input         qspi1_d2_in,
	input         qspi1_d3_in,
	output        qspi1_d0_out,
	output        qspi1_d1_out,
	output        qspi1_d2_out,
	output        qspi1_d3_out,
	output [3:0]  qspi1_dir,

	output        ahb_clk,
	output [1:0]  htrans,
	output        hwrite,
	output [30:0] haddr,
	output [2:0]  hsize,
	output [2:0]  hburst,
	output [3:0]  hprot,
	output        hmastlock,
	output [31:0] hwdata,
	input  [31:0] hrdata,
	input  [1:0]  hresp,
	input         hready,

	input         apb_clk,
	input         apb_rst,
	output [19: 0]paddr,
	output        psel,
	output        penable,
	output        pwrite,
	output [31:0] pwdata,
	output [3:0]  pstrobe,
	output [2:0]  pprot,
	input  [31:0] prdata,
	input         pready,
	input         pslverr,
	
	input         core_clk,
	input         timer_clk,
	input         core_reset,
	input         por_reset,
	input         nmi,
	input [22:0]  clic_irq
);

    wire ahb_clk_temp;

    generate if(MCU_DPLL_BYPASS == "ENABLE") 
        assign ahb_clk = core_clk;
    else
        assign ahb_clk = ahb_clk_temp;
    endgenerate

	PH1P_PHY_MCU
	#(
		.MCU_JTAG_SEL(MCU_JTAG_SEL),
		.MCU_RESET_VECTOR(MCU_RESET_VECTOR),
		.MCU_DPLL_FEED_TYPE("EXTERNAL"),
		.AHB_FREQ(AHB_FREQ),
		.QSPI1_FREQ(QSPI_FREQ),
        .MCU_DPLL_BYPASS(MCU_DPLL_BYPASS),
		.MCU_DPLL_POST_DIV(MCU_DPLL_POST_DIV)
	)PH1P_PHY_MCU_Inst
	(
        .core_sysrst(core_sysrst),
		.core_clk(core_clk),
		.timer_clk(timer_clk),
		.fb_clk(ahb_clk_temp),
		.core_reset(core_reset),
		.por_reset(por_reset),
		.core_clk_en(1'b1),
		.dbg_stop(1'b0),
		// Match the working RTC baseline; regeneration must pass MCU preflight.
		.dbg_stop_on_reset(1'b0),
		.dbg_stop_at_boot(1'b0),
		.dbg_mux_sel(2'h3),
		.nmi(nmi),
		.clic_irq(clic_irq),

		.jtag_tck(jtag_tck),
		.jtag_tms(jtag_tms),
		.jtag_tdi(jtag_tdi),
		.jtag_tdo(jtag_tdo),

		.gpio0_in(gpio0_in),
		.gpio0_out(gpio0_out),
		.gpio0_dir(gpio0_dir),

		.gpio1_in(gpio1_in),
		.gpio1_out(gpio1_out),
		.gpio1_dir(gpio1_dir),

		.gpio2_in(gpio2_in),
		.gpio2_out(gpio2_out),
		.gpio2_dir(gpio2_dir),

		.gpio3_in(gpio3_in),
		.gpio3_out(gpio3_out),
		.gpio3_dir(gpio3_dir),

		.gpio4_in(gpio4_in),
		.gpio4_out(gpio4_out),
		.gpio4_dir(gpio4_dir),

		.gpio5_in(gpio5_in),
		.gpio5_out(gpio5_out),
		.gpio5_dir(gpio5_dir),

		.gpio6_in(gpio6_in),
		.gpio6_out(gpio6_out),
		.gpio6_dir(gpio6_dir),

		.gpio7_in(gpio7_in),
		.gpio7_out(gpio7_out),
		.gpio7_dir(gpio7_dir),

		.uart0_tx(uart0_tx),
		.uart0_rx(uart0_rx),

		.uart1_tx(uart1_tx),
		.uart1_rx(uart1_rx),

		.i2c_sda_in(i2c_sda_in),
		.i2c_sda_out(i2c_sda_out),
		.i2c_sda_sel(i2c_sda_sel),
		.i2c_scl_in(i2c_scl_in),
		.i2c_scl_out(i2c_scl_out),
		.i2c_scl_sel(i2c_scl_sel),

		.qspi1_clk(qspi1_clk),
		.qspi1_ss(qspi1_ss),
		.qspi1_d0_in(qspi1_d0_in),
		.qspi1_d1_in(qspi1_d1_in),
		.qspi1_d2_in(qspi1_d2_in),
		.qspi1_d3_in(qspi1_d3_in),
		.qspi1_d0_out(qspi1_d0_out),
		.qspi1_d1_out(qspi1_d1_out),
		.qspi1_d2_out(qspi1_d2_out),
		.qspi1_d3_out(qspi1_d3_out),
		.qspi1_dir(qspi1_dir),

		.qspi0_dw32_sel(1'b0),
		.qspi0_spare_sel(1'b0),

		.ahb_clk(ahb_clk_temp),
		.htrans(htrans),
		.hwrite(hwrite),
		.haddr(haddr),
		.hsize(hsize),
		.hburst(hburst),
		.hprot(hprot),
		.hmastlock(hmastlock),
		.hwdata(hwdata),
		.hrdata(hrdata),
		.hresp(hresp),
		.hready(hready),

		.apb_clk(apb_clk),
		.apb_rst(apb_rst),
		.paddr(paddr),
		.psel(psel),
		.penable(penable),
		.pwrite(pwrite),
		.pwdata(pwdata),
		.pstrobe(pstrobe),
		.pprot(pprot),
		.prdata(prdata),
		.pready(pready),
		.pslverr(pslverr),

		.scan_mode_n(1'h1),
		.scan_en_n(1'h1),
		.pll_bypass(1'h0),
		.pib_pll_bypass(1'h0),
		.scan_rst_n(1'h0),
		.scan_in(73'h0),
		.wrapper_scan_in_0(1'h0),
		.wrapper_scan_in_1(1'h0),
		.chain_scan_in(1'h0)
	);

	PH1P_LOGIC_QSPI2MCU u_PH1P_LOGIC_QSPI2MCU
	(
		.qspi_pib_sel_i(1'b1)
	);

endmodule
