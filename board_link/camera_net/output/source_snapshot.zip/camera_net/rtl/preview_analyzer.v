// EG-only full-frame analysis. Reuses the camera project's component/shape RTL.
module preview_analyzer(
 input clk,proc_clk,rst,write_pixel,input [13:0] write_addr,input [7:0] write_data,
 input start,output reg done,output reg [127:0] result
);
 reg [7:0] image[0:14399];
 reg [7:0] pixel;
 reg [13:0] index;
 reg [7:0] x;
 reg [6:0] y;
 reg [3:0] state;
 reg red_seen,shape_seen;
 reg [21:0] watchdog;
 reg request,ack,seen;
 (* ASYNC_REG="TRUE" *) reg req1,req2,ack1,ack2;
 (* ASYNC_REG="TRUE" *) reg [1:0] reset_sync;
 reg [127:0] held_result;
 always @(posedge proc_clk or posedge rst)
  if(rst)reset_sync<=3;else reset_sync<={reset_sync[0],1'b0};
 wire proc_reset=reset_sync[1];
 always @(posedge clk or posedge rst)
  if(rst)begin request<=0;ack1<=0;ack2<=0;seen<=0;result<=0;done<=0;end
  else begin
   done<=0;if(start)request<=~request;
   ack1<=ack;ack2<=ack1;
   if(ack2!=seen)begin seen<=ack2;result<=held_result;done<=1;end
  end
 always @(posedge proc_clk or posedge proc_reset)
  if(proc_reset)begin req1<=0;req2<=0;end else begin req1<=request;req2<=req1;end
 wire tracker_rst_n=!proc_reset && state!=0;
 wire user=state==3 || state==6;
 wire de=state==4;
 wire [13:0] read_addr=de ? index+1'b1:index;
 wire [23:0] rgb={pixel[7:5],pixel[7:5],pixel[7:6],
                 pixel[4:2],pixel[4:2],pixel[4:3],{4{pixel[1:0]}}};
 wire red_new,red_valid,shape_new,shape_valid;
 wire [2:0] shape_kind;
 wire [11:0] rx0,ry0,rx1,ry1,rcx,rcy,sx0,sy0,sx1,sy1;
 wire [6:0] red_area,shape_area;
 always @(posedge clk)if(write_pixel && write_addr<14400)image[write_addr]<=write_data;
 always @(posedge proc_clk)pixel<=image[read_addr];
 red_shape_tracker #(.SHAPE_SUPPORT(0),.IMG_WIDTH(160),.IMG_HEIGHT(90),.SAMPLE_SHIFT(1),
  .ACQUIRE_PERCENT(1),.RETAIN_PERCENT(1),.CONFIRM_FRAMES(1),.LOST_FRAMES(1)) u_red(
  .I_clk(proc_clk),.I_rst_n(tracker_rst_n),.I_enable(1'b1),.I_reacquire(1'b0),
  .I_user(user),.I_de(de),.I_data(rgb),.I_shape_mode(1'b0),
  .O_new_result(red_new),.O_valid(red_valid),.O_state(),.O_shape_type(),
  .O_x0(rx0),.O_y0(ry0),.O_x1(rx1),.O_y1(ry1),.O_cx(rcx),.O_cy(rcy),
  .O_error_x(),.O_error_y(),.O_dir_x(),.O_dir_y(),.O_level_x(),.O_level_y(),.O_area_percent(red_area));
 red_shape_tracker #(.SHAPE_SUPPORT(1),.IMG_WIDTH(160),.IMG_HEIGHT(90),.SAMPLE_SHIFT(1),
  .ACQUIRE_PERCENT(1),.RETAIN_PERCENT(1),.CONFIRM_FRAMES(1),.LOST_FRAMES(1)) u_shape(
  .I_clk(proc_clk),.I_rst_n(tracker_rst_n),.I_enable(1'b1),.I_reacquire(1'b0),
  .I_user(user),.I_de(de),.I_data(rgb),.I_shape_mode(1'b1),
  .O_new_result(shape_new),.O_valid(shape_valid),.O_shape_type(shape_kind),.O_state(),
  .O_x0(sx0),.O_y0(sy0),.O_x1(sx1),.O_y1(sy1),.O_cx(),.O_cy(),
  .O_error_x(),.O_error_y(),.O_dir_x(),.O_dir_y(),.O_level_x(),.O_level_y(),.O_area_percent(shape_area));
 always @(posedge proc_clk or posedge proc_reset)begin
  if(proc_reset)begin state<=0;index<=0;x<=0;y<=0;ack<=0;held_result<=0;red_seen<=0;shape_seen<=0;watchdog<=0;end
  else begin
   case(state)
    0:if(req2!=ack)begin state<=1;index<=0;x<=0;y<=0;red_seen<=0;shape_seen<=0;watchdog<=0;end
    1:state<=2;
    2:state<=3;
    3:state<=4;
    4:begin
     index<=index+1'b1;
     if(x==159)begin x<=0;state<=5;end else x<=x+1'b1;
    end
    5:if(y==89)state<=6;else begin y<=y+1'b1;state<=4;end
    6:state<=7;
    7:begin
     if(red_new)red_seen<=1;
     if(shape_new)shape_seen<=1;
     if(red_seen && shape_seen)begin
      held_result<={6'd0,shape_valid,red_valid,5'd0,shape_kind,rcx[7:0],rcy[7:0],
       rx0[7:0],ry0[7:0],rx1[7:0],ry1[7:0],sx0[7:0],sy0[7:0],sx1[7:0],sy1[7:0],
       1'b0,red_area,1'b0,shape_area,8'd160,8'd90};
      ack<=req2;state<=0;
     end else if(watchdog==22'h3fffff)begin
      held_result<=128'h8000000000000000000000000000a05a;ack<=req2;state<=0;
     end else watchdog<=watchdog+1'b1;
    end
    default:state<=0;
   endcase
  end
 end
endmodule
