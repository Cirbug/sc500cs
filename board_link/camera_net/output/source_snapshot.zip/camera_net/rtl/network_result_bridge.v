// Frame-boundary publication of the slave result into existing HDMI/MCU ports.
module network_result_bridge(
 input clk,rst_n,frame_start,reacquire,red_enable,shape_enable,
 input [159:0] snapshot,
 output reg new_result,output red_valid,shape_valid,output [2:0] shape_type,
 output [1:0] track_state,dx,dy,lx,ly,
 output [11:0] rx0,ry0,rx1,ry1,cx,cy,sx0,sy0,sx1,sy1,
 output signed [12:0] ex,ey,output [6:0] area
);
 reg [31:0] seen;
 reg [127:0] result;
 reg [7:0] age;
 function [11:0] scale(input [7:0] v);
  scale=({4'd0,v}<<3)+({4'd0,v}<<2);
 endfunction
 wire fresh=seen!=0 && age<90 && !result[127];
 assign red_valid=red_enable && fresh && result[120];
 assign shape_valid=shape_enable && fresh && result[121];
 assign shape_type=shape_valid?result[114:112]:0;
 assign track_state=red_valid?1:0;
 assign rx0=scale(result[95:88]);assign ry0=scale(result[87:80]);
 assign rx1=scale(result[79:72])+11;assign ry1=scale(result[71:64])+11;
 assign cx=scale(result[111:104])+6;assign cy=scale(result[103:96])+6;
 assign sx0=scale(result[63:56]);assign sy0=scale(result[55:48]);
 assign sx1=scale(result[47:40])+11;assign sy1=scale(result[39:32])+11;
 assign ex=red_valid?$signed({1'b0,cx})-13'sd960:13'sd0;
 assign ey=red_valid?$signed({1'b0,cy})-13'sd540:13'sd0;
 wire [12:0] ax=ex[12]?-ex:ex,ay=ey[12]?-ey:ey;
 assign dx=!red_valid || ax<=48 ? 0:(ex[12]?1:2);
 assign dy=!red_valid || ay<=36 ? 0:(ey[12]?1:2);
 assign lx=dx==0?0:(ax>=400?3:(ax>=160?2:1));
 assign ly=dy==0?0:(ay>=300?3:(ay>=120?2:1));
 assign area=red_valid?result[30:24]:0;
 always @(posedge clk or negedge rst_n)
  if(!rst_n)begin seen<=0;result<=0;age<=255;new_result<=0;end
  else begin
   new_result<=0;
   if(reacquire)begin seen<=snapshot[159:128];age<=255;end
   else if(frame_start)begin
    if(snapshot[159:128]!=seen && snapshot[159:128]!=0)begin
     seen<=snapshot[159:128];result<=snapshot[127:0];age<=0;new_result<=1;
    end else if(age!=255)age<=age+1'b1;
   end
  end
endmodule
