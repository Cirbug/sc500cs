spi_text\main.o: ../Core/Src/main.c
spi_text\main.o: ../Core/Inc/main.h
spi_text\main.o: ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal.h
spi_text\main.o: ../Core/Inc/stm32f1xx_hal_conf.h
spi_text\main.o: ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_rcc.h
spi_text\main.o: ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_def.h
spi_text\main.o: ../Drivers/CMSIS/Device/ST/STM32F1xx/Include/stm32f1xx.h
spi_text\main.o: ../Drivers/CMSIS/Device/ST/STM32F1xx/Include/stm32f103xb.h
spi_text\main.o: ../Drivers/CMSIS/Include/core_cm3.h
spi_text\main.o: F:\Keil v5\ARM\ARMCC\Bin\..\include\stdint.h
spi_text\main.o: ../Drivers/CMSIS/Include/cmsis_version.h
spi_text\main.o: ../Drivers/CMSIS/Include/cmsis_compiler.h
spi_text\main.o: ../Drivers/CMSIS/Include/cmsis_armcc.h
spi_text\main.o: ../Drivers/CMSIS/Device/ST/STM32F1xx/Include/system_stm32f1xx.h
spi_text\main.o: ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal.h
spi_text\main.o: ../Drivers/STM32F1xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h
spi_text\main.o: F:\Keil v5\ARM\ARMCC\Bin\..\include\stddef.h
spi_text\main.o: ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_rcc_ex.h
spi_text\main.o: ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_gpio.h
spi_text\main.o: ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_gpio_ex.h
spi_text\main.o: ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_exti.h
spi_text\main.o: ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_dma.h
spi_text\main.o: ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_dma_ex.h
spi_text\main.o: ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_cortex.h
spi_text\main.o: ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_flash.h
spi_text\main.o: ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_flash_ex.h
spi_text\main.o: ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_pwr.h
spi_text\main.o: ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_spi.h
spi_text\main.o: ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_uart.h
spi_text\main.o: F:\Keil v5\ARM\ARMCC\Bin\..\include\stdarg.h
spi_text\main.o: F:\Keil v5\ARM\ARMCC\Bin\..\include\stdio.h
