<?xml version="1.0" encoding="UTF-8"?>
<Project Version="3" Minor="2" Path="C:/Users/21397/Desktop/fpga1/sc500cs/board_link/camera_net">
    <Project_Created_Time />
    <TD_Encoding>UTF-8</TD_Encoding>
    <TD_Version>6.2.168116</TD_Version>
    <Name>camera_network</Name>
    <HardWare>
        <Family>PH1</Family>
        <Device>PH1P35MDG324</Device>
        <Speed>-3</Speed>
    </HardWare>
    <Source_Files>
    <Verilog>
      <File Path="../../user_source/hdl_source/video_in.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="1" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/video_out.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="2" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/mc_to_user_interface.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="3" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/signal_delay.v">
        <FileInfo>
          <Attr Name="AutoExcluded" Val="true" />
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="4" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/awb.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="5" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/ph1p35_ddr/ph1p35_324_ddr_wrapper.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="6" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/isp/csi_unpacket_2lane.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="7" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/isp/isp_top.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="8" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/isp/raw10_unpacket_2lane.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="9" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/isp/uial2axis.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="10" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/isp/demosaic_4x_2_0/bilinear_interpolation.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="11" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/isp/demosaic_4x_2_0/demosaic.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="12" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/isp/demosaic_4x_2_0/line_buffer_demosaic.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="13" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/isp/demosaic_4x_2_0/mipi_to_raw_converter.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="14" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/isp/demosaic_4x_2_0/raw_matrix_3x3_buffer.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="15" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/isp/demosaic_4x_2_0/zhenghe.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="16" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/isp/data128_96/data128_96.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="17" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/isp/data96_128/data96_128.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="18" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/image_correction.v">
        <FileInfo>
          <Attr Name="AutoExcluded" Val="true" />
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="19" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/uics500_cfg/SC500GainTbl.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="20" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/uics500_cfg/uicfgcs500.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="21" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/uics500_cfg/uics500reg.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="22" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/uics500_cfg/uics500regAE.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="23" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/uics500_cfg/uii2c.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="24" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/uiisp_beta/ae_set.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="25" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/hdmi_tx.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="26" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/hdmi_1_4b_transmitter_core_wrapper.enc.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="27" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/hdmi_phy_warpper.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="28" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/lane_lvds_10_1.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="29" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/vtc/uivtc.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="30" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/hdmi_mixer.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="31" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/hdmi_mixer_image9.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="32" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/I2S_receiver.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="33" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/audio_arc_calculate.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="34" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/key_remove_shakes.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="35" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/video_params.vh">
        <FileInfo>
          <Attr Name="AutoExcluded" Val="true" />
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="36" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/mcu_ui_apb_regs.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="37" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/ui_osd.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="38" />
        </FileInfo>
      </File>
      <File Path="design_top_wrapper_net.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="39" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/focus_metric.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="40" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/lens_i2c_ctrl.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="41" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/ds3231_i2c_ctrl.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="42" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/servo_pwm_2ch.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="43" />
        </FileInfo>
      </File>
      <File Path="anlogic_logo_rom_trim.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="44" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/logo2_rom.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="45" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/red_tracking_osd.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="46" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/osd_char_lib.v">
        <FileInfo>
          <Attr Name="AutoExcluded" Val="true" />
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="47" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/image_features_99.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="48" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/red_target_tracker.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="49" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/rgb24_denoise_9.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="50" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/image_effects_9.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="51" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/sd_recorder.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="52" />
        </FileInfo>
      </File>
      <File Path="vendor/crc32_check.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
        <Attr Name="CompileOrder" Val="53" /></FileInfo>
      </File>
      <File Path="vendor/crc32_gen.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
        <Attr Name="CompileOrder" Val="54" /></FileInfo>
      </File>
      <File Path="vendor/mac_cache.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
        <Attr Name="CompileOrder" Val="55" /></FileInfo>
      </File>
      <File Path="vendor/uiarp_layer.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
        <Attr Name="CompileOrder" Val="56" /></FileInfo>
      </File>
      <File Path="vendor/uiarp_rx.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
        <Attr Name="CompileOrder" Val="57" /></FileInfo>
      </File>
      <File Path="vendor/uiarp_tx.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
        <Attr Name="CompileOrder" Val="58" /></FileInfo>
      </File>
      <File Path="vendor/uiicmp_pkg_ctrl.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
        <Attr Name="CompileOrder" Val="59" /></FileInfo>
      </File>
      <File Path="vendor/uiicmp_pkg_tx.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
        <Attr Name="CompileOrder" Val="60" /></FileInfo>
      </File>
      <File Path="vendor/uiip_arp_tx.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
        <Attr Name="CompileOrder" Val="61" /></FileInfo>
      </File>
      <File Path="vendor/uiip_header_checksum.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
        <Attr Name="CompileOrder" Val="62" /></FileInfo>
      </File>
      <File Path="vendor/uiip_layer.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
        <Attr Name="CompileOrder" Val="63" /></FileInfo>
      </File>
      <File Path="vendor/uiip_rx.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
        <Attr Name="CompileOrder" Val="64" /></FileInfo>
      </File>
      <File Path="vendor/uiip_tx.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
        <Attr Name="CompileOrder" Val="65" /></FileInfo>
      </File>
      <File Path="vendor/uimac_layer.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
        <Attr Name="CompileOrder" Val="66" /></FileInfo>
      </File>
      <File Path="vendor/uimac_rx.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
        <Attr Name="CompileOrder" Val="67" /></FileInfo>
      </File>
      <File Path="vendor/uimac_tx.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
        <Attr Name="CompileOrder" Val="68" /></FileInfo>
      </File>
      <File Path="vendor/uimac_tx_frame_ctrl.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
        <Attr Name="CompileOrder" Val="69" /></FileInfo>
      </File>
      <File Path="vendor/uimac_tx_pause_ctrl.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
        <Attr Name="CompileOrder" Val="70" /></FileInfo>
      </File>
      <File Path="vendor/uiudp_layer.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
        <Attr Name="CompileOrder" Val="71" /></FileInfo>
      </File>
      <File Path="vendor/uiudp_rx.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
        <Attr Name="CompileOrder" Val="72" /></FileInfo>
      </File>
      <File Path="vendor/uiudp_stack.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
        <Attr Name="CompileOrder" Val="73" /></FileInfo>
      </File>
      <File Path="vendor/uiudp_tx.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
        <Attr Name="CompileOrder" Val="74" /></FileInfo>
      </File>
      <File Path="vendor/uiphyrst.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
        <Attr Name="CompileOrder" Val="75" /></FileInfo>
      </File>
      <File Path="vendor/udp_pkg_buf.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
        <Attr Name="CompileOrder" Val="76" /></FileInfo>
      </File>
      <File Path="vendor/uiip_arp_rx.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
        <Attr Name="CompileOrder" Val="77" /></FileInfo>
      </File>
      <File Path="vendor/shift_ram_8bit.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
        <Attr Name="CompileOrder" Val="78" /></FileInfo>
      </File>
      <File Path="vendor/rgmii_interface.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
        <Attr Name="CompileOrder" Val="79" /></FileInfo>
      </File>
      <File Path="vendor/net_pll.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
        <Attr Name="CompileOrder" Val="80" /></FileInfo>
      </File>
      <File Path="vendor/ph1p_phy_pll_wrapper_d2616deaaa79.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
        <Attr Name="CompileOrder" Val="81" /></FileInfo>
      </File>
      <File Path="rtl/camera_network.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
        <Attr Name="CompileOrder" Val="82" /></FileInfo>
      </File>
      <File Path="rtl/network_result_bridge.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
        <Attr Name="CompileOrder" Val="83" /></FileInfo>
      </File>
      <File Path="rtl/preview_analyzer.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
        <Attr Name="CompileOrder" Val="84" /></FileInfo>
      </File>
      <File Path="rtl/preview_capture.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
        <Attr Name="CompileOrder" Val="85" /></FileInfo>
      </File>
      <File Path="rtl/preview_receiver.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
        <Attr Name="CompileOrder" Val="86" /></FileInfo>
      </File>
      <File Path="rtl/preview_sender.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
        <Attr Name="CompileOrder" Val="87" /></FileInfo>
      </File>
    </Verilog>
    <System_Verilog>
      <File Path="../../user_source/hdl_source/mipi_dphy_rx/mipi_dphy_rx_ph1p_mipiio_wrapper.sv">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="88" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/mipi_dphy_rx/ph1p_mipiio_rx_wrapper.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="89" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/mipi_dphy_rx/byte_aligner.enc.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="90" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/mipi_dphy_rx/byte_aligner_wrapper.enc.sv">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="91" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/mipi_dphy_rx/channel_aligner.enc.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="92" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/mipi_dphy_rx/channel_aligner_wrapper.enc.sv">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="93" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/mipi_dphy_rx/hs_detect.enc.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="94" />
        </FileInfo>
      </File>
    </System_Verilog>
    <ADC_FILE>
      <File Path="pin_net.adc">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="constraint_1" />
          <Attr Name="CompileOrder" Val="95" />
        </FileInfo>
      </File>
    </ADC_FILE>
    <SDC_FILE>
      <File Path="timing_net.sdc">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="constraint_1" />
          <Attr Name="CompileOrder" Val="96" />
        </FileInfo>
      </File>
    </SDC_FILE>
    <IP_FILE>
      <File Path="../../user_source/ip_source/PLL/PLL.xml">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="97" />
        </FileInfo>
      </File>
      <File Path="../../user_source/ip_source/w128_d512_fifo/w128_d512_fifo.xml">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="98" />
        </FileInfo>
      </File>
      <File Path="../../user_source/ip_source/w155_d512_fifo/w155_d512_fifo.xml">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="99" />
        </FileInfo>
      </File>
      <File Path="../../user_source/ip_source/blk_mem_gen_awb_delay_signal/blk_mem_gen_awb_delay_signal.xml">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="100" />
        </FileInfo>
      </File>
      <File Path="../../user_source/ip_source/divider/divider.ipc">
        <FileInfo>
          <Attr Name="AutoExcluded" Val="true" />
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="101" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/ph1p35_ddr/ddr2/ddr2.xml">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="102" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/isp/demosaic_4x_2_0/blk_mem_gen_zhenghe/blk_mem_gen_zhenghe.xml">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="103" />
        </FileInfo>
      </File>
      <File Path="../../user_source/hdl_source/isp/demosaic_4x_2_0/blk_mem_gen_demosaic/blk_mem_gen_demosaic.xml">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="104" />
        </FileInfo>
      </File>
      <File Path="../../td_project/al_ip/RISCV_F6F1D1P0_0/RISCV_F6F1D1P0_0.xml">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&amp;R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="105" />
        </FileInfo>
      </File>
    </IP_FILE>
  </Source_Files>
  <FileSets>
        <FileSet Name="design_1" Type="DesignFiles">
        </FileSet>
        <FileSet Name="constraint_1" Type="ConstrainFiles">
        </FileSet>
    </FileSets>
    <TOP_MODULE>
        <LABEL>design_top_wrapper</LABEL>
        <MODULE>design_top_wrapper</MODULE>
        <CREATEINDEX>user</CREATEINDEX>
    </TOP_MODULE>
    <Property>
    </Property>
    <Device_Settings>
    </Device_Settings>
    <Configurations>
    </Configurations>
    <Runs>
        <Run Name="syn_1" Type="Synthesis" ConstraintSet="constraint_1" Description="" Active="true">
            <Strategy Name="Default_Synthesis_Strategy">
            </Strategy>
            <UserParams>
            </UserParams>
        </Run>
        <Run Name="phy_1" Type="PhysicalDesign" ConstraintSet="constraint_1" Description="" SynRun="syn_1" Active="true">
            <Strategy Name="Default_PhysicalDesign_Strategy">
            </Strategy>
            <UserParams>
            </UserParams>
        </Run>
    </Runs>
    <Project_Settings>
    </Project_Settings>
</Project>